#модули и переменные
import os, subprocess, time

#импортировать модули в автоматизацию
def modules():
    with open("Auto/new_automatization.py", "a", encoding="utf-8") as f:
        f.write(f'import os, subprocess, time\n')

#автоматизации
def auto():
    modules()
    while True:
        os.system("cls")
        print("Напишите команду, которая добавиться в автоматизацию!")
        auto=input("> ")
        if auto.startswith("написать"):
            txt=auto[9:]
            with open("Auto/new_automatization.py", "a", encoding="utf-8") as f:
                f.write(f'print("{txt}")\n')
            print("Команда добавлена в файл!")
            time.sleep(3)
        elif auto.startswith("перезаписать"):
            with open("Auto/new_automatization.py", "w", encoding="utf-8") as f:
                pass
            print("Файл перезаписан!")
            modules()
            time.sleep(3)
        elif auto.startswith("открыть приложение"):
            txt=auto[19:]
            with open("Auto/new_automatization.py", "a", encoding="utf-8") as f:
                f.write(f'subprocess.run(r"{txt}")\n')
            print("Команда добавлена в файл!")
            time.sleep(3)
        elif auto.startswith("подождать"):
            numbers=auto[10:]
            with open("Auto/new_automatization.py", "a", encoding="utf-8") as f:
                f.write(f'time.sleep({int(numbers)})\n')
            print("Команда добавлена в файл!")
            time.sleep(3)
        elif auto.startswith("открыть ссылку"):
            txt=auto[15:]
            with open("Auto/new_automatization.py", "a", encoding="utf-8") as f:
                f.write(f'subprocess.Popen("start {txt}", shell = True)\n')
            print("Команда добавлена в файл!")
            time.sleep(3)
        elif auto.startswith("ввести"):
            txt=auto[7:]
            with open("Auto/new_automatization.py", "a", encoding="utf-8") as f:
                f.write(f'subprocess.Popen("{txt}", shell = True)\n')
            print("Команда добавлена в файл!")
            time.sleep(3)
        elif auto.startswith("стоп"):
            os.system("cls")
            print("Поздравляю! Автоматизация создана")
            print("Теперь вы можете запускать сразу несколько задач одним файлом!")
            print("Это окно закроется через 3 секунды")
            time.sleep(3)
            break
        
#менюшка
def menu():
    os.system("cls")
    print("========[версия 0.1]=========")
    print("[1] - сделать автоматизацию")
    print("[2] - поддержка автора (очень приятно :3)")
    print("[0] - выход")
    print("=============================")
    print("/made by blox0ped")
    menu_choice=input("> ")
    if menu_choice == "1":
        auto()
    if menu_choice == "2":
        os.system("cls")
        print("Сейчас вы перейдёте на страницу доната, для поддержки автора")
        os.system("start https://www.donationalerts.com/r/bloxoped1")
        print("Этот диалог закроется через 5 секунд")
        time.sleep(5)
        menu()
    if menu_choice == "3":
        print("Выход")
menu()